#!/bin/bash

rm /usr/bin/pihole-panel
rm -R /usr/lib/pihole-panel
rm /usr/share/applications/pihole-panel.desktop

echo "Done!"
